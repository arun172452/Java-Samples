package com.example.demo.observable;

import io.reactivex.Observable;
import io.reactivex.ObservableEmitter;

import java.util.List;

public class Server {

    public static Observable<MyInfo> getInfo(List<String> names){

        return Observable.create(sub -> emit(sub,names));
    }

    private static void emit(ObservableEmitter<MyInfo> sub, List<String> names) {
        System.out.println("Started emitting...");
        for(int i=0;i<3;i++){
            names.stream().map(MyInfo::fetch).forEach(sub::onNext);
        }
        sub.onComplete();
    }


}
