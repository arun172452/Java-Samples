package com.example.demo.observable;

import io.reactivex.Observable;

import java.util.Arrays;
import java.util.List;

public class ListenerMain {
    public static void main(String[] args) {
        final List<String>  names = Arrays.asList("Arun","kumar","Lekkalapudi");

        final Observable<MyInfo> listener = Server.getInfo(names);

        listener.subscribe(System.out::println,
                System.out::println,
                () -> System.out.println("Completed"));
    }
}
